#!/bin/bash
#https://www.linux.com/tutorials/how-operate-linux-spycams-motion/
#netcam_url value http://http//192.168.2.52:4747/videostream.cgi";

set -e

if [[ -e /etc/centos-release || -e /etc/redhat-release ]]; then

	echo "CentOS is not supported"
	exit 1;
fi

if [[ "$EUID" -ne 0 ]]; then

	echo "  Sorry, you need to run this as root"
	exit 1;
fi

if [[ -e "/etc/lsb-release" ]];then
DISTRIB_ID=$(cat /etc/lsb-release | grep DISTRIB_ID= | sed -e 's/DISTRIB_ID= *//');
CODENAME=$(cat /etc/lsb-release | grep DISTRIB_CODENAME= | sed -e 's/DISTRIB_CODENAME= *//');
LOCATION="/usr/src/v4l2loopback-1.1";
V4L2_LOOPBACK="v4l2loopback";
KERNEL_VERSION=$(uname -r);
V4L2_LOOPBACK_DIR="/lib/modules/$KERNEL_VERSION/extra";
V4L2_LOOPBACK_KO="v4l2loopback.ko";
OK_CARRIER=$(ip link | grep -E "state UP" | grep -E ": <" | cut -d ':' -f1)
NO_CARRIER=$(ip link | grep -c BROADCAST,MULTICAST,UP)
tmp_file=$(mktemp)
echo "$(lsmod | grep "v4l2loopback" -no | grep "2:" | cut -d ':' -f2)" > $tmp_file
media=$(cat $tmp_file )

clear
echo "     ///////////////////////////////////////////"
echo "        Your distribution is: $DISTRIB_ID";
echo "        The taste of distribution $CODENAME";
echo "     ///////////////////////////////////////////"
sleep 2
fi

if [  "$OK_CARRIER" = ""  ]; then
clear
echo "  Please connect to the internet"
echo
echo "  No carrier !"
echo
echo "  No internet connection !"
echo
echo "  Please provide internet access "
echo
sleep 2
exit 1;
fi

update_network() {

if [[  $(ip addr | grep inet | grep -v inet6 | grep -vEc '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}') -eq 1   ]]; then
echo
if [[  "$OK_CARRIER" != "$NO_CARRIER"  ]]; then
echo "   ok carrier"
sleep 1
number_of_ips=$(ip addr | grep inet | grep -v inet6 | grep -vEc '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}')

        while :
	do
        clear
		echo "I need to ask some questions to continue the installation."
		echo
		echo "Which ipv4 is the camera connected to:"
		ip addr | grep inet | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | cut -d '/' -f 1 | grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | nl -s ') '
		read -p   "IPv4 address [1]: " ip_number
		until [[ -z "$ip_number" || "$ip_number" =~ ^[0-9]+$ && "$ip_number" -le "$number_of_ips" ]]; do
			echo "$ip_number: invalid selection."
			read -p "IPv4 address [1]: " ip_number
		done
		[[ -z "$ip_number" ]] && ip_number="1"
		ip=$(ip addr | grep inet | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | cut -d '/' -f 1 | grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | sed -n "$ip_number"p)

		if echo "$ip" | grep -qE '^(10\.|172\.1[6789]\.|172\.2[0-9]\.|172\.3[01]\.|192\.168)'; then
			echo
			echo "Fill in the number the camera is connected to and complete address."
			get_partial_ip=$(ip addr | grep inet | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.' | cut -d '/' -f 1 | grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.' | sed -n "$ip_number"p)
			read -p "Please complete the IP4V address: [$get_partial_ip]: " camera_ip

			until [[ -z "$camera_ip" || "$camera_ip" =~ ^[0-9{1,3}]+$ && "$camera_ip" -le 255 ]]; do

				echo [$camera_ip]: "invalid selection."
				read -p "Pease complete IP4v address [$get_partial_ip]:" camera_ip
			done

			[ -z "$camera_ip" ] && camera_ip="$ip"
		fi

			echo "What port do you want listening to?"

			read -p "Port [4747]: " port

			until [[ -z "$port" || "$port" =~ ^[0-9]+$ && "$port" -le 65535 ]]; do

			echo "$port: invalid selection."

			read -p "Port [4747]: " port

			done

			[[ -z "$port" ]] && port="4747"
			NETCAM="value http:\/\/http:\/\/$get_partial_ip$camera_ip:$port\/videostream.cgi";
			echo Camera ip: $get_partial_ip$camera_ip
			echo Camera port: $port
			sleep 2
			if [[ "$media" != "v4l2loopback" ]]; then
			install_v4l2loopback
			else
			echo "   Setting up motion"
			echo
	        	config_droid
			echo "   I'm found the $media module installed"
			echo
			exit;
			fi;
		done
fi
echo
echo "  No carrier!"
echo
sleep 1
fi
}

if [[ -d /usr/src/v4l2loopback ]]; then
	echo
if [[ ! -d /usr/src/v4l2loopback-1.1 ]]; then
	clear
	echo 
	echo "  Copping $V4L2_LOOPBACK too $LOCATION"
	sleep 2
	cp -R $V4L2_LOOPBACK $LOCATION;
else
	echo
	echo "  I'm "$V4L2_LOOPBACK-1.1" directory find."
	echo
	sleep 1
fi
else
	echo
	echo "  D'not "$V4L2_LOOPBACK" directory find."
	echo
	sleep 1
exit;
fi

etc_modules_load_d() {
        printf "videodev\n$V4L2_LOOPBACK\n" \
                 > /etc/modules-load.d/cam.conf

}

etc_modules() {
        echo "Adding driver to /etc/modules"
        cp /etc/modules /etc/modules.bak
        prevperm=$(stat -c %a /etc/modules)
        chmod 666 /etc/modules
        [[ ! $(egrep "^videodev$" /etc/modules) ]] && echo "videodev" >> /etc/modules
        [[ ! $(egrep "^$V4L2_LOOPBACK" /etc/modules) ]] && echo "$V4L2_LOOPBACK" >> /etc/modules
        chmod $prevperm /etc/modules
}

etc_default_motion() {
	prevperm=$(stat -c %a /etc/default/motion)
        chmod 666 /etc/default/motion
	sed -i "s/^"start_motion_daemon=no/"start_motion_daemon=yes/g" /etc/default/motion
        chmod $prevperm /etc/default/motion
}

etc_motion_motion() {
        prevperm=$(stat -c %a /etc/motion/motion.conf)
        chmod 666 /etc/motion/motion.conf
	sed -i "s/^; netcam_url.*/netcam_url/g" /etc/motion/motion.conf
	sed -i "s/^netcam_url.*/netcam_url $NETCAM/g" /etc/motion/motion.conf
	chmod $prevperm /etc/motion/motion.conf
}


config_droid(){

if [ ! -e "$V4L2_LOOPBACK_DIR/$V4L2_LOOPBACK_KO" ]
then
	echo "$V4L2_LOOPBACK_KO not built.. Failure"
	exit 1;
fi

[[ -d "/etc/modprobe.d/" ]] && echo "options " > /etc/modprobe.d/cam.conf

if [ -e "/etc/modules" ]
then
        etc_modules
elif [ -d "/etc/modules-load.d" ]
then
        etc_modules_load_d
else
        echo "Warning: Unknown distro. Webcam module may not load after a  reboot :("
fi
	etc_default_motion
	etc_motion_motion
	service motion restart
echo "Done"
exit 1;
}


install_v4l2loopback() {
cd /usr/src/
echo "Building $V4L2_LOOPBACK_KO"
make -C  v4l2loopback-1.1;
make -C  v4l2loopback-1.1 install;
dkms add -m $V4L2_LOOPBACK -v 1.1
dkms build -m $V4L2_LOOPBACK -v 1.1
dkms install -m $V4L2_LOOPBACK -v 1.1
echo "Registering webcam device"
modprobe videodev;
echo "Running depmod"
depmod -a;
make -C $LOCATION clean
modprobe $V4L2_LOOPBACK;
config_droid
}

sources_ok() {
			unset UNIVERSE
			UNIVERSE=$(grep -i "security universe" /etc/apt/sources.list | cut -d " " -f4)
			if  [ "$UNIVERSE" == "" ]; then
			echo
			echo "Please, you need to add the universe library "
			echo
			sleep 2
			else
			install_packages
			fi
}

install_packages() {

unset ARGS
sleep 2
for i in gcc make motion dkms linux-headers-$KERNEL_VERSION
do
if [ $(dpkg-query -W -f='${Status}' $i 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
  ARGS="$ARGS $i"
fi
done
if [ "$ARGS" <> " " ]; then
	while :
	do
	clear
		echo "   You need install: $ARGS packages"
		echo
		echo "   1) Add a new packages"
		echo "   2) Exit"
		read -p "Select an option: " option
		until [[ "$option" =~ ^[1-2]$ ]];
	do
			echo "$option: invalid selection."
			read -p "Select an option: " option
	done
		case "$option" in
			1)
			echo
			echo
			echo "   Update libary...."
			echo
			sleep 1
			clear
			apt update
			sleep 1
			clear
			echo
			echo
			echo "   Instalaing packages $ARGS ...."
			echo
			sleep 1
			clear
			echo
			echo
			apt install $ARGS -y
			update_network
			;;
			2)
			echo
			echo
			echo "   Aborting instaling"
			exit;;
		esac
	done

 else
    clear
    echo
    echo "   All required packages are installed...."
    sleep 2
    update_network
 fi
}

add_sources() {
	sources_tmp=$(mktemp)
	sources_file=/etc/apt/sources.list
        echo "   Adding universe to $sources_file"
        sleep 2
	cp $sources_file $sources_file.bk
	file=$(grep "security" $sources_file | cut -d "]" -f1)
	echo "$file" > $sources_tmp
	sed -i "s/^deb http:\/\/security.ubuntu.com\/ubuntu\/ $CODENAME-security main restricted.*/deb http:\/\/archive.ubuntu.com\/ubuntu\/ $CODENAME universe/g" $sources_tmp
	data=$(cat $sources_tmp)
	echo "$data" >> $sources_file
	unset data
	sed -i "s/^deb http:\/\/archive.ubuntu.com\/ubuntu\/ $CODENAME universe.*/deb http:\/\/security.ubuntu.com\/ubuntu\/ $CODENAME-security universe/g" $sources_tmp
	data=$(cat $sources_tmp)
	echo "$data" >> $sources_file
install_packages
}

unset UNIVERSE
UNIVERSE=$(grep -i "security universe" /etc/apt/sources.list | cut -d " " -f4)

if [[ "$DISTRIB_ID" = "Ubuntu" ]]; then
sleep 1

if [ "$UNIVERSE" != "universe" ]; then
echo
echo "You need to add the universe library "
echo "deb http://archive.ubuntu.com/ubuntu/ $CODENAME universe"
echo "deb http://security.ubuntu.com/ubuntu/ $CODENAME-security universe"
sleep 2

	while :
	do
	clear
		echo "   You need to add the universe library"
		echo
		echo "   1) Add automatic"
		echo "   2) Edit source.list"
		echo "   3) Exit"
		read -p "Select an option: " option
		until [[ "$option" =~ ^[1-3]$ ]];
	do
			echo "$option: invalid selection."
			read -p "Select an option: " option
	done
		case "$option" in
			1)
			clear
			echo "   Finishing automatic editing file...."
			add_sources
			;;
			2)
			clear
			echo "   Finishing manual editing file.."
			apt  edit-sources
			sources_ok
			;;
			3)
			echo
			echo "   Aborting instaling"
			exit;;

		esac
	done
fi
echo
echo "  I'm found the $UNIVERSE library"
echo
fi
install_packages



