#!/bin/bash
set -e
V4L2_LOOPBACK="v4l2loopback";
NETCAM="value http:\/\/http:\/\/192.168.2.52:4747\/videostream.cgi";
KERNEL_VER="linux-headers-`uname -r`";

if [[ -e /etc/centos-release || -e /etc/redhat-release ]]; then

	echo "CentOS is not supported"
	exit 1;
fi

if [[ "$EUID" -ne 0 ]]; then

	echo "Sorry, you need to run this as root"
	exit 1;
fi

etc_modules_load_d() {
        printf "videodev\n$V4L2_LOOPBACK\n" \
                 > /etc/modules-load.d/cam.conf

}

etc_modules() {
        echo "Adding driver to /etc/modules"
        cp /etc/modules /etc/modules.bak
        prevperm=`stat -c %a /etc/modules`
        chmod 666 /etc/modules
        [[ ! $(egrep "^videodev$" /etc/modules) ]] && echo "videodev" >> /etc/modules
        [[ ! $(egrep "^$V4L2_LOOPBACK" /etc/modules) ]] && echo "$V4L2_LOOPBACK" >> /etc/modules
        chmod $prevperm /etc/modules
}

etc_default_motion() {
	prevperm=
        prevperm=`stat -c %a /etc/default/motion`
        chmod 666 /etc/default/motion
	sed -i "s/^"start_motion_daemon=no/"start_motion_daemon=yes/g" /etc/default/motion
        chmod $prevperm /etc/default/motion
}

etc_motion_motion() {
	prevperm=
        prevperm=`stat -c %a /etc/motion/motion.conf`
        chmod 666 /etc/motion/motion.conf
	sed -i "s/^; netcam_url.*/netcam_url/g" /etc/motion/motion.conf
	sed -i "s/^netcam_url.*/netcam_url $NETCAM/g" /etc/motion/motion.conf
	chmod $prevperm /etc/motion/motion.conf
}


if [[ -e "/etc/lsb-release" ]];then
DISTRIB_ID=`cat /etc/lsb-release | grep DISTRIB_ID= | sed -e 's/DISTRIB_ID= *//'`;
CODENAME=`cat /etc/lsb-release | grep DISTRIB_CODENAME= | sed -e 's/DISTRIB_CODENAME= *//'`;
clear
echo
echo "        Your distribution is: $DISTRIB_ID";
echo "        The taste of distribution $CODENAME";fi
sleep 2
unset ARGS

for i in gcc make motion $KENEL_VER dkms
do
if [ $(dpkg-query -W -f='${Status}' $i 2>/dev/null | grep -c "ok installed") -eq 0 ]; then
  ARGS="$ARGS $i"
fi
done
if [ "$ARGS" <> " " ]; then
	while :
	do
	clear
		echo "   You need install: $ARGS packages"
		echo
		echo "   1) Add a new packages"
		echo "   2) Exit"
		read -p "Select an option: " option
		until [[ "$option" =~ ^[1-2]$ ]];
	do
			echo "$option: invalid selection."
			read -p "Select an option: " option
	done
		case "$option" in
			1)
			echo
			echo "   Update libary ...."
			apt  update
			echo
			echo "   Instalaing $ARGS ...."
			apt install $ARGS -y
			return 0;
			;;
			2)
			echo
			echo "   Aborting instaling"
			exit;;
		esac
	done
fi
make -C $V4L2_LOOPBACK;
make -C $V4L2_LOOPBACK install;

echo "Registering webcam device"
modprobe videodev;
echo "Running depmod"
cp -R v4l2loopback /usr/src/v4l2loopback-1.1
dkms add -m v4l2loopback -v 1.1
dkms build -m v4l2loopback -v 1.1
dkms install -m v4l2loopback -v 1.1
depmod -a;
modprobe $V4L2_LOOPBACK;
[[ -d "/etc/modprobe.d/" ]] && echo "options $V4L2_LOOPBACK" > /etc/modprobe.d/cam.conf

if [ -e "/etc/modules" ]
then
        etc_modules
elif [ -d "/etc/modules-load.d" ]
then
        etc_modules_load_d
else
        echo "Warning: Unknown distro. Webcam module may not load after a  reboot :("
fi
	etc_default_motion
	etc_motion_motion
	service motion restart
echo "Done"


